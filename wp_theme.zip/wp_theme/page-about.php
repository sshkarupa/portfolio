<?php get_header(); ?>

<?php while ( have_posts() ) : the_post(); ?>

  <div class="content-header">
    <?php echo get_the_post_thumbnail(4); ?>
    <h2><?php echo get_bloginfo('name'); ?></h2>
    <p><?php echo get_bloginfo('description'); ?></p>
  </div>
  <div class="content-body">
    <?php the_content(); ?>
  </div>

<? endwhile; ?>

<?php get_footer(); ?>