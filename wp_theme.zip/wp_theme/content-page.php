
  <div class="content-header">
    <?php echo get_the_post_thumbnail(4); ?>
    <h2><?php echo get_bloginfo('name'); ?></h2>
    <p><?php echo get_bloginfo('description'); ?></p>
  </div>
  <div class="content-body">
    <?php the_content(); ?>
  </div>